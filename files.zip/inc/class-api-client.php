<?php
namespace Custom_Secure_Payment;

class API_Client {
    private static $token_option = 'csp_plugin_token';
    private static $token_exp_option = 'csp_plugin_token_expiry';

    public static function init() {
        // No hooks required unless you need to expose API test endpoints
    }

    public static function get_settings() {
        return get_option('csp_plugin_settings', []);
    }

    public static function get_bearer_token($force = false) {
        $settings = self::get_settings();
        if (empty($settings['applicationId']) || empty($settings['appKey']) || empty($settings['appSecret']) || empty($settings['baseUrl'])) {
            return false;
        }
        $current_token = get_option(self::$token_option, '');
        $token_expiry = get_option(self::$token_exp_option, 0);
        if (!$force && $current_token && $token_expiry > time() + 60) {
            return $current_token;
        }
        $url = rtrim($settings['baseUrl'], '/') . '/auth/token';
        $response = wp_remote_post($url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode([
                'applicationId' => $settings['applicationId'],
                'appKey' => $settings['appKey'],
                'appSecret' => $settings['appSecret']
            ]),
            'timeout' => 20
        ]);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!empty($body['access_token']) && !empty($body['expires_in'])) {
            update_option(self::$token_option, $body['access_token']);
            update_option(self::$token_exp_option, time() + intval($body['expires_in']));
            return $body['access_token'];
        }
        return false;
    }
}