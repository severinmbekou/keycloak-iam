<?php
namespace Custom_Secure_Payment;

class Ajax_Handler {
    public static function init() {
        add_action('wp_ajax_csp_process_payment', [self::class, 'ajax_process_payment']);
        add_action('wp_ajax_nopriv_csp_process_payment', [self::class, 'ajax_process_payment']);
        add_action('wp_ajax_csp_poll_payment', [self::class, 'ajax_poll_payment']);
        add_action('wp_ajax_nopriv_csp_poll_payment', [self::class, 'ajax_poll_payment']);
    }

    public static function ajax_process_payment() {
        check_ajax_referer('csp_ajax_nonce', 'nonce');
        $phone = sanitize_text_field($_POST['phoneNumber'] ?? '');
        if (!preg_match('/^\+?\d{10,15}$/', $phone)) {
            wp_send_json_error(['message' => 'Invalid phone number format.']);
        }
        $token = API_Client::get_bearer_token();
        if (!$token) {
            wp_send_json_error(['message' => 'Unable to authenticate with payment API.']);
        }
        $settings = API_Client::get_settings();
        $apiUrl = rtrim($settings['baseUrl'], '/') . '/payments/initiate';
        $response = wp_remote_post($apiUrl, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode(['phoneNumber' => $phone]),
            'timeout' => 30
        ]);
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code === 201 && !empty($body['processingId'])) {
            wp_send_json_success(['processingId' => $body['processingId']]);
        } else {
            wp_send_json_error(['message' => 'Payment initiation failed.']);
        }
    }

    public static function ajax_poll_payment() {
        check_ajax_referer('csp_ajax_nonce', 'nonce');
        $processingId = sanitize_text_field($_POST['processingId'] ?? '');
        $token = API_Client::get_bearer_token();
        if (!$token) {
            wp_send_json_error(['message' => 'Unable to authenticate with payment API.']);
        }
        $settings = API_Client::get_settings();
        $apiUrl = rtrim($settings['baseUrl'], '/') . '/payments/status/' . $processingId;
        $start = time();
        $timeout = 180;
        do {
            $response = wp_remote_get($apiUrl, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token
                ],
                'timeout' => 15
            ]);
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($body['status']) && $body['status'] === 'confirmed') {
                wp_send_json_success(['message' => 'Payment confirmed!']);
            }
            if (time() - $start > $timeout) break;
            sleep(5);
        } while (true);
        wp_send_json_error(['message' => 'Payment confirmation timed out.']);
    }
}