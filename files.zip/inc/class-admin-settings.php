<?php
namespace Custom_Secure_Payment;

class Admin_Settings {
    public static function init() {
        add_action('admin_menu', [self::class, 'admin_menu']);
        add_action('admin_init', [self::class, 'register_settings']);
    }
    public static function admin_menu() {
        add_options_page('Custom Secure Payment Settings', 'Secure Payment', 'manage_options', 'csp_plugin_settings', [self::class, 'settings_page']);
    }
    public static function register_settings() {
        register_setting('csp_plugin_group', 'csp_plugin_settings');
    }
    public static function settings_page() {
        $settings = get_option('csp_plugin_settings', []);
        ?>
        <div class="wrap">
            <h1>Custom Secure Payment Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('csp_plugin_group');
                do_settings_sections('csp_plugin_group');
                ?>
                <table class="form-table">
                    <tr><th>Application ID</th>
                        <td><input type="text" name="csp_plugin_settings[applicationId]" value="<?= esc_attr($settings['applicationId'] ?? '') ?>" required /></td></tr>
                    <tr><th>App Key</th>
                        <td><input type="text" name="csp_plugin_settings[appKey]" value="<?= esc_attr($settings['appKey'] ?? '') ?>" required /></td></tr>
                    <tr><th>App Secret</th>
                        <td><input type="text" name="csp_plugin_settings[appSecret]" value="<?= esc_attr($settings['appSecret'] ?? '') ?>" required /></td></tr>
                    <tr><th>Base URL</th>
                        <td><input type="url" name="csp_plugin_settings[baseUrl]" value="<?= esc_attr($settings['baseUrl'] ?? '') ?>" required /></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}