<?php
namespace Custom_Secure_Payment;

class WooCommerce_Integration {
    public static function init() {
        add_action('woocommerce_after_checkout_form', [self::class, 'show_payment_form'], 12);
    }
    public static function show_payment_form() {
        echo Payment_Form::render_payment_form();
    }
}