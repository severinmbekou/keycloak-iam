<?php
namespace Custom_Secure_Payment;

class Payment_Form {
    public static function init() {
        add_shortcode('custom_payment_form', [self::class, 'shortcode_payment_form']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_scripts']);
    }
    public static function shortcode_payment_form() {
        return self::render_payment_form();
    }
    public static function render_payment_form() {
        ob_start();
        ?>
        <form id="csp-payment-form">
            <label for="csp-phone-number">Phone Number:</label>
            <input type="tel" id="csp-phone-number" name="phoneNumber" required pattern="^(\+?\d{10,15})$" placeholder="+1234567890">
            <button type="submit">Pay Now</button>
            <div id="csp-payment-status"></div>
        </form>
        <?php
        return ob_get_clean();
    }
    public static function enqueue_scripts() {
        wp_enqueue_script('csp-plugin-js', plugin_dir_url(__DIR__) . 'assets/csp-plugin.js', ['jquery'], false, true);
        wp_localize_script('csp-plugin-js', 'cspPluginAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('csp_ajax_nonce')
        ]);
    }
}