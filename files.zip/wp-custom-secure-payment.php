<?php
/*
Plugin Name: Custom Secure Payment for WooCommerce
Description: Integrates a secure payment process via API, supporting WooCommerce and a standalone shortcode.
Version: 1.0.0
Author: severinmbekou
*/

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/inc/class-admin-settings.php';
require_once __DIR__ . '/inc/class-api-client.php';
require_once __DIR__ . '/inc/class-payment-form.php';
require_once __DIR__ . '/inc/class-ajax-handler.php';
require_once __DIR__ . '/inc/class-woocommerce-integration.php';

// Initialize plugin components
Custom_Secure_Payment\Admin_Settings::init();
Custom_Secure_Payment\API_Client::init();
Custom_Secure_Payment\Payment_Form::init();
Custom_Secure_Payment\Ajax_Handler::init();
Custom_Secure_Payment\WooCommerce_Integration::init();