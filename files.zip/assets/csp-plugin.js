jQuery(document).ready(function($){
    $('#csp-payment-form').on('submit', function(e){
        e.preventDefault();
        var phone = $('#csp-phone-number').val();
        $('#csp-payment-status').text('Processing...');
        $.post(cspPluginAjax.ajax_url, {
            action: 'csp_process_payment',
            phoneNumber: phone,
            nonce: cspPluginAjax.nonce
        }, function(resp){
            if(resp.success && resp.data.processingId){
                pollPayment(resp.data.processingId);
            } else {
                $('#csp-payment-status').text(resp.data.message || 'Payment failed.');
            }
        });
    });

    function pollPayment(pid){
        var start = Date.now();
        function poll(){
            $.post(cspPluginAjax.ajax_url, {
                action: 'csp_poll_payment',
                processingId: pid,
                nonce: cspPluginAjax.nonce
            }, function(resp){
                if(resp.success){
                    $('#csp-payment-status').text(resp.data.message);
                    window.location.href = '/dashboard'; // adjust URL as needed
                } else if(Date.now() - start > 180000) {
                    $('#csp-payment-status').text(resp.data.message || 'Payment confirmation timed out.');
                } else {
                    setTimeout(poll, 5000);
                }
            });
        }
        poll();
    }
});